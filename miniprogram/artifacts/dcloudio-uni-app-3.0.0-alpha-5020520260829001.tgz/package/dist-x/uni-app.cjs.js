'use strict';

var vue = require('vue');
var shared = require('@vue/shared');
var uniShared = require('@dcloudio/uni-shared');

function assertKey(key, shallow = false) {
    if (!key) {
        throw new Error(`${shallow ? 'shallowSsrRef' : 'ssrRef'}: You must provide a key.`);
    }
}
function proxy(target, track, trigger) {
    return new Proxy(target, {
        get(target, prop) {
            track();
            if (shared.isObject(target[prop])) {
                return proxy(target[prop], track, trigger);
            }
            return Reflect.get(target, prop);
        },
        set(obj, prop, newVal) {
            const result = Reflect.set(obj, prop, newVal);
            trigger();
            return result;
        },
    });
}
const globalData = {};
const ssrServerRef = (value, key, shallow = false) => {
    assertKey(key, shallow);
    const ctx = vue.getCurrentInstance() && vue.useSSRContext();
    let state;
    if (ctx) {
        const __uniSSR = ctx[uniShared.UNI_SSR] || (ctx[uniShared.UNI_SSR] = {});
        state = __uniSSR[uniShared.UNI_SSR_DATA] || (__uniSSR[uniShared.UNI_SSR_DATA] = {});
    }
    else {
        state = globalData;
    }
    state[key] = uniShared.sanitise(value);
    // SSR 模式下 watchEffect 不生效 https://github.com/vuejs/vue-next/blob/master/packages/runtime-core/src/apiWatch.ts#L283
    // 故自定义ref
    return vue.customRef((track, trigger) => {
        const customTrigger = () => (trigger(), (state[key] = uniShared.sanitise(value)));
        return {
            get: () => {
                track();
                if (!shallow && shared.isObject(value)) {
                    return proxy(value, track, customTrigger);
                }
                return value;
            },
            set: (v) => {
                value = v;
                customTrigger();
            },
        };
    });
};
const ssrRef = (value, key) => {
    {
        return ssrServerRef(value, key);
    }
};
const shallowSsrRef = (value, key) => {
    {
        return ssrServerRef(value, key, true);
    }
};
function getSsrGlobalData() {
    return uniShared.sanitise(globalData);
}

/**
 * uni 对象是跨实例的，而此处列的 API 均是需要跟当前实例关联的，比如 requireNativePlugin 获取 dom 时，依赖当前 weex 实例
 */
function getCurrentSubNVue() {
    return uni.getSubNVueById(plus.webview.currentWebview().id);
}
function requireNativePlugin(name) {
    return weex.requireModule(name);
}

function formatAppLog(type, filename, ...args) {
    // @ts-expect-error
    if (uni.__log__) {
        // @ts-expect-error
        uni.__log__(type, filename, ...args);
    }
    else {
        console[type].apply(console, [...args, filename]);
    }
}
function formatLog(type, filename, ...args) {
    if (filename) {
        args.push(filename);
    }
    console[type].apply(console, args);
}

function resolveEasycom(component, easycom) {
    return typeof component === 'string' ? easycom : component;
}

/// <reference types="@dcloudio/types" />
function isUniApp(target) {
    const proxy = target === null || target === void 0 ? void 0 : target.proxy;
    const ctx = target === null || target === void 0 ? void 0 : target.ctx;
    const type = target === null || target === void 0 ? void 0 : target.type;
    return ((proxy === null || proxy === void 0 ? void 0 : proxy.$mpType) === 'app' || (ctx === null || ctx === void 0 ? void 0 : ctx.$mpType) === 'app' || (type === null || type === void 0 ? void 0 : type.mpType) === 'app');
}
function getAppVm() {
    const app = getApp({ allowDefault: true });
    return app === null || app === void 0 ? void 0 : app.$vm;
}
function removeAppHook(vm, name, hook, originalHook, target) {
    const hooks = vm.$[name];
    if (!Array.isArray(hooks)) {
        return;
    }
    for (let i = hooks.length - 1; i >= 0; i--) {
        const appHook = hooks[i];
        if (appHook === hook ||
            (originalHook &&
                appHook.__uni_app_hook === originalHook &&
                appHook.__uni_app_target === target)) {
            hooks.splice(i, 1);
        }
    }
}
function isTargetInvalid(target) {
    var _a;
    return (target === null || target === void 0 ? void 0 : target.isUnmounted) || (target === null || target === void 0 ? void 0 : target.__isUnload) || ((_a = target === null || target === void 0 ? void 0 : target.root) === null || _a === void 0 ? void 0 : _a.__isUnload);
}
function queueRemoveAppHook(removeHook) {
    Promise.resolve().then(removeHook);
}
function injectAppHook(lifecycle, hook, target) {
    const isAppInstance = isUniApp(target);
    const appVm = getAppVm();
    const appInstance = isAppInstance ? target : appVm === null || appVm === void 0 ? void 0 : appVm.$;
    if (appInstance) {
        if (isAppInstance) {
            vue.injectHook(lifecycle, hook, appInstance);
            return;
        }
        let isRemoved = false;
        let wrappedHook;
        const removeHook = () => {
            if (isRemoved || !wrappedHook) {
                return;
            }
            isRemoved = true;
            const appVm = getAppVm();
            appVm && removeAppHook(appVm, lifecycle, wrappedHook, hook, target);
        };
        const appHook = ((...args) => {
            if (isRemoved || isTargetInvalid(target)) {
                queueRemoveAppHook(removeHook);
                return;
            }
            return hook(...args);
        });
        wrappedHook = vue.injectHook(lifecycle, appHook, appInstance);
        if (wrappedHook) {
            wrappedHook.__uni_app_hook = hook;
            wrappedHook.__uni_app_target = target;
            if (isTargetInvalid(target)) {
                removeHook();
            }
        }
        // 如果不是App，那么需要监听当前target的销毁事件，来移除App上的钩子
        if (target && wrappedHook) {
            vue.onBeforeUnmount(() => removeHook(), target);
            vue.injectHook(uniShared.ON_UNLOAD, () => removeHook(), target);
        }
    }
}
// function isUniPage(target: ComponentInternalInstance | null): boolean {
//   if (target && 'renderer' in target) {
//     return target.renderer === 'page'
//   }
//   return true
// }
const createLifeCycleHook = (lifecycle, flag = 0 /* HookFlags.UNKNOWN */) => (hook, target = vue.getCurrentInstance()) => {
    if (vue.isInSSRComponentSetup)
        return;
    if (flag === 1 /* HookFlags.APP */) {
        injectAppHook(lifecycle, hook, target);
        return;
    }
    // post-create lifecycle registrations are noops during SSR
    vue.injectHook(lifecycle, hook, target);
};
const onAppShow = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_SHOW, 1 /* HookFlags.APP */);
const onAppHide = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_HIDE, 1 /* HookFlags.APP */);
const onShow = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_SHOW, 2 /* HookFlags.PAGE */);
const onHide = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_HIDE, 2 /* HookFlags.PAGE */);
const onLaunch = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_LAUNCH, 1 /* HookFlags.APP */);
const onError = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_ERROR, 1 /* HookFlags.APP */);
const onThemeChange = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_THEME_CHANGE, 1 /* HookFlags.APP */);
const onPageNotFound = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_PAGE_NOT_FOUND, 1 /* HookFlags.APP */);
const onUnhandledRejection = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_UNHANDLE_REJECTION, 1 /* HookFlags.APP */);
const onLastPageBackPress = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_LAST_PAGE_BACK_PRESS, 1 /* HookFlags.APP */);
const onExit = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_EXIT, 1 /* HookFlags.APP */);
const onInit = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_INIT, 2 /* HookFlags.PAGE */ | 4 /* HookFlags.COMPONENT */);
// 小程序如果想在 setup 的 props 传递页面参数，需要定义 props，故同时暴露 onLoad 吧
const onLoad = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_LOAD, 2 /* HookFlags.PAGE */);
const onReady = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_READY, 2 /* HookFlags.PAGE */);
const onUnload = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_UNLOAD, 2 /* HookFlags.PAGE */);
const onResize = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_RESIZE, 2 /* HookFlags.PAGE */);
const onBackPress = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_BACK_PRESS, 2 /* HookFlags.PAGE */);
const onPageScroll = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_PAGE_SCROLL, 2 /* HookFlags.PAGE */);
const onTabItemTap = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_TAB_ITEM_TAP, 2 /* HookFlags.PAGE */);
const onReachBottom = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_REACH_BOTTOM, 2 /* HookFlags.PAGE */);
const onPullDownRefresh = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_PULL_DOWN_REFRESH, 2 /* HookFlags.PAGE */);
const onSaveExitState = 
/*#__PURE__*/ createLifeCycleHook(uniShared.ON_SAVE_EXIT_STATE, 2 /* HookFlags.PAGE */);
const onTitleClick = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_TITLE_CLICK, 2 /* HookFlags.PAGE */);
const onShareTimeline = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_SHARE_TIMELINE, 2 /* HookFlags.PAGE */);
const onShareChat = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_SHARE_CHAT, 2 /* HookFlags.PAGE */);
const onAddToFavorites = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_ADD_TO_FAVORITES, 2 /* HookFlags.PAGE */);
const onShareAppMessage = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_SHARE_APP_MESSAGE, 2 /* HookFlags.PAGE */);
const onCopyUrl = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_COPY_URL, 2 /* HookFlags.PAGE */);
const onUploadDouyinVideo = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_UPLOAD_DOUYIN_VIDEO, 2 /* HookFlags.PAGE */);
const onLiveMount = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_LIVE_MOUNT, 2 /* HookFlags.PAGE */);
const onNavigationBarButtonTap = /*#__PURE__*/ createLifeCycleHook(uniShared.ON_NAVIGATION_BAR_BUTTON_TAP, 2 /* HookFlags.PAGE */);
const onNavigationBarSearchInputChanged = 
/*#__PURE__*/ createLifeCycleHook(uniShared.ON_NAVIGATION_BAR_SEARCH_INPUT_CHANGED, 2 /* HookFlags.PAGE */);
const onNavigationBarSearchInputClicked = 
/*#__PURE__*/ createLifeCycleHook(uniShared.ON_NAVIGATION_BAR_SEARCH_INPUT_CLICKED, 2 /* HookFlags.PAGE */);
const onNavigationBarSearchInputConfirmed = 
/*#__PURE__*/ createLifeCycleHook(uniShared.ON_NAVIGATION_BAR_SEARCH_INPUT_CONFIRMED, 2 /* HookFlags.PAGE */);
const onNavigationBarSearchInputFocusChanged = 
/*#__PURE__*/ createLifeCycleHook(uniShared.ON_NAVIGATION_BAR_SEARCH_INPUT_FOCUS_CHANGED, 2 /* HookFlags.PAGE */);
const onPageShow = onShow;
const onPageHide = onHide;

function renderComponentSlot(slots, name, props = null) {
    if (slots[name]) {
        return slots[name](props);
    }
    return null;
}

Object.defineProperty(exports, "capitalize", {
  enumerable: true,
  get: function () { return shared.capitalize; }
});
Object.defineProperty(exports, "extend", {
  enumerable: true,
  get: function () { return shared.extend; }
});
Object.defineProperty(exports, "hasOwn", {
  enumerable: true,
  get: function () { return shared.hasOwn; }
});
Object.defineProperty(exports, "isPlainObject", {
  enumerable: true,
  get: function () { return shared.isPlainObject; }
});
exports.formatAppLog = formatAppLog;
exports.formatLog = formatLog;
exports.getCurrentSubNVue = getCurrentSubNVue;
exports.getSsrGlobalData = getSsrGlobalData;
exports.onAddToFavorites = onAddToFavorites;
exports.onAppHide = onAppHide;
exports.onAppShow = onAppShow;
exports.onBackPress = onBackPress;
exports.onCopyUrl = onCopyUrl;
exports.onError = onError;
exports.onExit = onExit;
exports.onHide = onHide;
exports.onInit = onInit;
exports.onLastPageBackPress = onLastPageBackPress;
exports.onLaunch = onLaunch;
exports.onLiveMount = onLiveMount;
exports.onLoad = onLoad;
exports.onNavigationBarButtonTap = onNavigationBarButtonTap;
exports.onNavigationBarSearchInputChanged = onNavigationBarSearchInputChanged;
exports.onNavigationBarSearchInputClicked = onNavigationBarSearchInputClicked;
exports.onNavigationBarSearchInputConfirmed = onNavigationBarSearchInputConfirmed;
exports.onNavigationBarSearchInputFocusChanged = onNavigationBarSearchInputFocusChanged;
exports.onPageHide = onPageHide;
exports.onPageNotFound = onPageNotFound;
exports.onPageScroll = onPageScroll;
exports.onPageShow = onPageShow;
exports.onPullDownRefresh = onPullDownRefresh;
exports.onReachBottom = onReachBottom;
exports.onReady = onReady;
exports.onResize = onResize;
exports.onSaveExitState = onSaveExitState;
exports.onShareAppMessage = onShareAppMessage;
exports.onShareChat = onShareChat;
exports.onShareTimeline = onShareTimeline;
exports.onShow = onShow;
exports.onTabItemTap = onTabItemTap;
exports.onThemeChange = onThemeChange;
exports.onTitleClick = onTitleClick;
exports.onUnhandledRejection = onUnhandledRejection;
exports.onUnload = onUnload;
exports.onUploadDouyinVideo = onUploadDouyinVideo;
exports.renderComponentSlot = renderComponentSlot;
exports.requireNativePlugin = requireNativePlugin;
exports.resolveEasycom = resolveEasycom;
exports.shallowSsrRef = shallowSsrRef;
exports.ssrRef = ssrRef;
